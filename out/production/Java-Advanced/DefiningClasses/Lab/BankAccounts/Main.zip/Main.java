
// Judge ready

package DefiningClasses.Lab.BankAccounts;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        Map<Integer, BankAccount> bankAccounts = new HashMap<>();
        while (true) {
            String command = s.nextLine();
            if ("End".equals(command)) {
                break;
            } else {
                String[] tokens = command.split("\\s+");
                switch (tokens[0]) {
                    case "Create":
                        createNewBankAccount(bankAccounts);
                        break;
                    case "Deposit": {
                        depositAmount(bankAccounts, tokens);
                        break;
                    }
                    case "SetInterest":
                        setInterest(tokens);
                        break;
                    case "GetInterest": {
                        getAccumulatedInterest(bankAccounts, tokens);
                        break;
                    }
                }
            }
        }
    }

    private static void createNewBankAccount(Map<Integer, BankAccount> bankAccounts) {
        BankAccount newBankAccount = new BankAccount();
        int accountID = newBankAccount.getAccountID();
        bankAccounts.putIfAbsent(accountID, newBankAccount);
        BankAccount.printAccountIsCreated(accountID);
    }

    private static void depositAmount(Map<Integer, BankAccount> bankAccounts, String[] tokens) {
        int targetID = Integer.parseInt(tokens[1]);
        double amount = Double.parseDouble(tokens[2]);

        if (bankAccounts.containsKey(targetID)) {
            bankAccounts.get(targetID).deposit(amount);
            BankAccount.printAmountIsDeposited(targetID, amount);
        } else {
            System.out.println("Account does not exist");
        }
    }

    private static void setInterest(String[] tokens) {
        double interest = Double.parseDouble(tokens[1]);
        BankAccount.setInterestRate(interest);
    }

    private static void getAccumulatedInterest(Map<Integer, BankAccount> bankAccounts, String[] tokens) {
        int targetID = Integer.parseInt(tokens[1]);
        int year = Integer.parseInt(tokens[2]);
        if (bankAccounts.containsKey(targetID)) {
            bankAccounts.get(targetID).printInterest(year);
        } else {
            System.out.println("Account does not exist");
        }
    }
}
